<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>S’identifier</title>
    <link rel="stylesheet" href="patient.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="left-panel">
        <main class="hero-section">
    <div class="left-content">
    <i class="fas fa-hospital"></i>
           <h4>main dans la main</h4>
        </div>
        <div class="right-panel">
            <h1>bienvenue</h1>
            <p>Vous avez le choix </p>
            <div class="login-options">
                <a href="jeu.html" class="option">
                    <img src="jeux.png" alt="jeux">
                    <span>jeux</span>
                </a>
                <a href="paiement.html" class="option">
                    <img src="pai.png" alt="paiement">
                    <span>paiment</span>
                </a>
                <a href="Consultation.html" class="option">
                    <img src="cos.png" alt="consultation">
                    <span>consultation</span>
                </a>
            </div>
            <a href="login-patient.php" class="back">Retour à l'accueil</a>
        </div>
    </div>
</body>
</html>
