<!DOCTYPE html>
<html lang="en">
<head>
 
    <meta charset="UTF-8">
   
    <title>Hospital Management System</title>
    
   
   
    <link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

    <body>
<header>
    <div class="top-bar">
    <li class="menu-active"><a href="index.php">Home</a></li>
        <a href="backend/doc/index.php">Doctor's Login</a>
        <a href="backend/admin/index.php">Administrator Login</a>
    </div>
</header>

<main class="hero-section">
    <div class="left-content">
    <i class="fas fa-hospital"></i>
    <h4>Main dans la Main</h4>
      
        </div>
    </div>

    <div class="right-content">
        <h1>Main dans la Main</h1>

        <h2>En ligne en Tunisie</h2>
        <p>
          
        </p>
        <a href="login-patient.php" class="btn">Démarrer</a>
    </div>
</main>

</body>
</html>
</body>
</html>
