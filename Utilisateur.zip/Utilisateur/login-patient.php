<?php
include('config.php');
session_start();



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = md5($_POST['pass']); 

    $sql = "SELECT * FROM users WHERE email='$email' AND pass='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $_SESSION['email'] = $email;
        header("location: dashboard.php");
    } else {
        $error = "Email ou mot de passe invalide.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <link rel="stylesheet" href="style-login-patient.css">
</head>
<body>
    <div class="login-box">
        <h2>Login</h2>
        <form method="post">
            <input type="text" name="email" placeholder="Email or phone number" required><br>
            <input type="password" name="pass" placeholder="Enter your password" required><br>
            <a href="patient.php" class="btn">login</a>
           
        </form>
        <p><a href="#">Forgot your password ?</a></p>
        <p>Don't have an account? <a href="register.php">Create a new account</a></p>
    </div>
</body>
</html>