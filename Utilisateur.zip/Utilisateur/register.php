<?php
include('config-register.php');

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first = $_POST['first_name'];
    $last = $_POST['last_name'];
    $email = $_POST['email'];
    $country = $_POST['country'];
    $password = $_POST['pass'];
    $confirm = $_POST['confirm_password'];

    if ($password !== $confirm) {
        $error = "Les mots de passe ne correspondent pas.";
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Cet email est déjà utilisé.";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, country, psd) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $first, $last, $email, $country, $hashed);

            if ($stmt->execute()) {
                $success = "Compte créé avec succès.";
            } else {
                $error = "Erreur lors de la création du compte.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create an account</title>
    <link rel="stylesheet" href="register.css">
</head>
<body>
<div class="container">
    <h2>Create an account</h2>
    <form method="post">
        <div class="row">
            <input type="text" name="last_name" placeholder="Last name" required>
            <input type="text" name="first_name" placeholder="First name" required>
        </div>
        <input type="email" name="email" placeholder="Email" required>
        <select name="country" required>
            <option value="">Choose your country</option>
            <option value="France">France</option>
            <option value="Canada">Canada</option>
            <option value="Morocco">Morocco</option>
            <option value="Other">Other</option>
        </select>
        <input type="password" name="password" placeholder="Password (minimum 8 characters)" minlength="8" required>
        <input type="password" name="confirm_password" placeholder="Confirm the password" required>
        <input type="submit" value="Create an account">
        <?php if ($error) echo "<p class='error'>$error</p>"; ?>
        <?php if ($success) echo "<p class='success'>$success</p>"; ?>
    </form>
    <p>Do you already have an account? <a href="login-patient.php">Login</a></p>
</div>
</body>
</html>