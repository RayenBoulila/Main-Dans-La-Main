<?php
session_start();
require_once('../config.php');
require_once('../auth.php');

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>About Us - Hospital Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />

</head>

<body>
    <!-- Begin page -->
    <div id="wrapper">
        <?php include('assets/inc/topbar.php'); ?>
        <?php include('assets/inc/sidebar.php'); ?>

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content">
                <!-- Start Content-->
                <div class="container-fluid">
                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="his_admin_dashboard.php">Dashboard</a></li>
                                        <li class="breadcrumb-item active">About Us</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">About Us</h4>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h4 class="header-title mb-3">Our Hospital</h4>
                                            <p class="text-muted">
                                                Welcome to our state-of-the-art hospital management system. We are committed to providing the highest quality healthcare services to our patients.
                                            </p>
                                            <p class="text-muted">
                                                Our hospital is equipped with modern facilities and staffed by experienced medical professionals dedicated to patient care and well-being.
                                            </p>
                                        </div>
                                        <div class="col-md-6">
                                            <h4 class="header-title mb-3">Our Mission</h4>
                                            <p class="text-muted">
                                                To provide exceptional healthcare services through advanced technology, compassionate care, and continuous improvement in medical practices.
                                            </p>
                                            <h4 class="header-title mb-3 mt-4">Our Vision</h4>
                                            <p class="text-muted">
                                                To be a leading healthcare institution recognized for excellence in patient care, medical education, and research.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end container-fluid -->
            </div>
            <!-- end content -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page content -->
        <!-- ============================================================== -->
    </div>
    <!-- END wrapper -->

    <!-- Vendor js -->
    <script src="assets/js/vendor.min.js"></script>

    <!-- App js -->
    <script src="assets/js/app.min.js"></script>
</body>
</html>