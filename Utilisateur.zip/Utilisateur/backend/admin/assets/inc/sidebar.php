<div class="left-side-menu">

                <div class="slimscroll-menu">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">

                        <ul class="metismenu" id="side-menu">

                            <li class="menu-title">Navigation</li>

                            <li>
                                <a href="his_admin_dashboard.php">
                                    <i class="fe-airplay"></i>
                                    <span> Dashboard </span>
                                </a>
                            </li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fab fa-accessible-icon "></i>
                                    <span> Patients </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_register_patient.php">Register Patient</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_view_patients.php">View Patients</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_manage_patient.php">Manage Patients</a>
                                    </li>
                                    <hr>
                                </ul>
                            </li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="mdi mdi-doctor"></i>
                                    <span> Rendez-Vous </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_add_rdv.php">Add rendez-vous</a>
                                    </li>
                                
                                    <li>
                                        <a href="his_admin_manage_employee.php">Manage Employees</a>
                                    </li>
                                    <hr>
                                </ul>
                            </li>

                            
                            <li>
                                <a href="javascript: void(0);">
                                    <i class="mdi mdi-cash-multiple "></i>
                                    <span> Paiement </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_add_acc.payable.php">Send ammount Acc. Doctor</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_manage_acc_payable.php">Manage ammount Acc. Doctor</a>
                                    </li>
                                    <hr>
                                    <li>
                                        <a href="his_admin_add_acc_receivable.php">Add Acc. Patient Receivable</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_manage_acc_receivable.php">Manage Acc. Patient Receivable</a>
                                    </li>
                                    <hr>
                                    
                                    
                                </ul>
                            </li>

                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fas fa-lock"></i>
                                    <span> Password Resets </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_manage_password_resets.php">Manage</a>
                                    </li>                                    
                                </ul>
                            </li>
                            <li>
                                <a href="javascript: void(0);">
                                    <i class="fas fa-info-circle"></i>
                                    <span> About </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="nav-second-level" aria-expanded="false">
                                    <li>
                                        <a href="his_admin_about.php">About Us</a>
                                    </li>
                                    <li>
                                        <a href="his_admin_contact.php">Contact</a>
                                    </li>                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>